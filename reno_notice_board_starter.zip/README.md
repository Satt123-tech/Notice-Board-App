# Reno Notice Board

Run:
npm install
npx prisma generate
npx prisma db push
npm run dev

Improvements: image upload, better UI, filtering.

AI Usage: Used ChatGPT to scaffold boilerplate and documentation.
