import {useState} from 'react';
export default function AddNotice(){
const [f,setF]=useState({title:'',body:'',category:'General',priority:'Normal',publishDate:''});
const submit=async(e)=>{e.preventDefault();await fetch('/api/notices',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(f)});alert('Saved');};
return <form onSubmit={submit} style={{maxWidth:600,margin:'20px auto',display:'grid',gap:10}}>
<input required placeholder='Title' onChange={e=>setF({...f,title:e.target.value})}/>
<textarea required placeholder='Body' onChange={e=>setF({...f,body:e.target.value})}/>
<select onChange={e=>setF({...f,category:e.target.value})}><option>Exam</option><option>Event</option><option>General</option></select>
<select onChange={e=>setF({...f,priority:e.target.value})}><option>Normal</option><option>Urgent</option></select>
<input required type='date' onChange={e=>setF({...f,publishDate:e.target.value})}/>
<button>Create Notice</button>
</form>
}