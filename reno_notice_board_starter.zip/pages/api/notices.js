import { prisma } from '../../lib/prisma';
export default async function handler(req,res){
 if(req.method==='POST'){
   const data=req.body;
   const notice=await prisma.notice.create({data:{...data,publishDate:new Date(data.publishDate)}});
   return res.status(200).json(notice);
 }
 return res.status(405).end();
}