import { prisma } from '../lib/prisma';
export async function getServerSideProps(){
 const notices=await prisma.notice.findMany();
 notices.sort((a,b)=>a.priority===b.priority?new Date(b.publishDate)-new Date(a.publishDate):a.priority==='Urgent'?-1:1);
 return {props:{notices:JSON.parse(JSON.stringify(notices))}};
}
export default function Notices({notices}){
return <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(260px,1fr))',gap:16,padding:20}}>
{notices.map(n=><div key={n.id} style={{border:'1px solid #ddd',padding:12}}>
{n.priority==='Urgent'&&<span style={{color:'red'}}>Urgent</span>}
<h3>{n.title}</h3><p>{n.body}</p><small>{n.category}</small>
</div>)}
</div>
}